import os
import sys 
import time
import json
from subprocess import Popen

start = time.time()

init = open('init.json')
init_data = json.load(init)

#cfd_exe = '"'+r"C:\Program Files\Autodesk\CFD 2016\CFD.exe"+ '"'
cfd_exe = '"'+ str(init_data[0]['cfd_path']) + '"'
print(cfd_exe)



################################### Use to create setup file with boundary volume

def cfd_run(cfdst_path, sim_path, stp_path):
	print("running :", csv_path)
	with open(csv_path, "w") as f:
		f.write(str("{},{},{}".format(csv_path, sim_path, stp_path) ) ) 

	cmd_command = "{} -script {}".format(cfd_exe, "boundary.py")
	os.system(cmd_command)


#################################### Use with Mars GD with input random seed

def cfd_run_single(cfdst_path, sim_path, stp_path, seed_input):
	print("\n\nrunning :", cfdst_path, "\ninput number: ", seed_input)

	with open("seed.txt", "w") as f:
		f.write( seed_input )
	
	with open('source.csv', "w") as f1:
		f1.write(str("{},{},{},{}".format(cfdst_path, sim_path, stp_path, seed_input) ) ) 

	cmd_command = "{} -script {}".format(cfd_exe, "windy_pidgy.py")
	print("CFD Runner GO! ", cmd_command)
	os.system(cmd_command)

	cmd_command_2 = "{} -script {}".format(cfd_exe, "viz.py")
	print("CFD Visualization GO! ", cmd_command_2)
	os.system(cmd_command_2)

try:
	if sys.argv[1] == "1":
		print("\nRunning in CMD mode\n")

		cfdst_fp = sys.argv[2]
		cfd_fp = sys.argv[3]
		stp_fp = sys.argv[4]
		seed_num = sys.argv[5]

		cfd_run_single(cfdst_fp, cfd_fp, stp_fp, seed_num)

except:
	try:
		print("\nSELECT MODE\n")
		print('\n 0 = Create base CFD file \n 1 = Run CFD model with new inputs \n 2 - CFD Setup w/ Manual Inputs \n')
		mode=int(input('Select Mode: '))
		
		if mode == 0:
			stp_fp=str(input('Input Path to STP file: '))
			cfd_run( "base.cfdst", "models\\working\\base\\", stp_fp)

		if mode == 1:
			print("\nRunning CFD Analysis Single\n\n")
			seed_num = str(input( "Input Parameters: " ))
			cfd_run_single("mars_windy.cfdst", "C:\\test\\cfd\\models\\mars\\mars_windy\\", "C:\\test\\cfd\\models\\mars\\bakery\\".format(seed_num) , seed_num)
		
		if mode == 2:
			print("\nCFD Setup Manual Inputs\n\n")
			cfdst_fp = str(input( "CDFST Name: " ))
			#csv_name = str(input( "CFD Sim File: " ))
			cfd_fp = str(input( "CFD Filepath: " ))
			stp_fp = str(input( "Geometry Filepath: " ))
			seed_num = str(input( "Input Parameters: " ))
			#cfd_run_single("base.cfdst", "C:\\test\\cfd\\models\\working\\base\\", "C:\\test\\cfd\\models\\", seed_num)
			cfd_run_single(cfdst_fp, cfd_fp, stp_fp, seed_num)

	except Exception as e:
		mode = 0
		print("\n~~~Exception~~~\n", e)

