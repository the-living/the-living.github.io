__author__ = 'Damon, TheLiving'
__email__ = 'damon.lau@autodesk.com'

from CFD import Setup
from CFD import DSE
from CFD import DC
from CFD import Results

import os
import time
import sys
import shutil
import json

base_dir = os.curdir

init = open('init.json')
init_data = json.load(init)

txt_file = r"source.csv"

f2 = open(txt_file)														
t = f2.read()
DSE.UI.ShowMessage(t)

source_list = t.split(",")

cfd_file = source_list[1]+source_list[0]
stp_name = source_list[3]
stp_path = source_list[2]+stp_name+".stp"


stp_path = t
print("argv ", t)

DSE.UI.ShowMessage("\n\nHello CFD World!\n\n")
DSE.UI.ShowMessage("run time " + time.ctime()+"\n\n")

study = Setup.DesignStudy.Create()			
study.open(cfd_file) 														

scenario = study.getActiveScenario()
design = study.design( "Design 1" )

results = scenario.results()
results.activate()

simage1 = DSE.UI.SaveSummaryImages("screencap_summaryImage.JPG")
simage2 = DSE.UI.SaveResultsImage("screenshot_resultsImage.JPG")
simage = results.saveImage("screen_saveImage.JPG")

start_path = source_list[1] + "Design 1\\Scenario 1\\screen_saveImage.JPG"
end_path = str( init_data[0]['img_path'] + stp_name + "-" + str(time.time()) + ".JPG")

print("start path ", start_path)
print("end path ", end_path)

shutil.copyfile(start_path , end_path) 

print("screen caps output and copied")