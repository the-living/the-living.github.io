__author__ = 'Damon, TheLiving'
__email__ = 'damon.lau@autodesk.com'

from CFD import Setup
from CFD import DSE
from CFD import DC
from CFD import Results

import os
import time
import sys
import shutil
import json

DSE.UI.ShowMessage("\n\nHello CFD World!\n\n")
DSE.UI.ShowMessage(time.ctime()+"\n\n")

# cfd_file = r"C:\test\cfd\models\mars\mars_windy\mars_windy.cfdst"

base_dir = os.curdir

init = open('init.json')
init_data = json.load(init)

txt_file = r"source.csv"
f2 = open(txt_file)														
t = f2.read()
DSE.UI.ShowMessage(t)

source_list = t.split(",")

cfd_file = source_list[1]+source_list[0]
stp_name = source_list[3]
stp_path = source_list[2]+stp_name+".stp"

###############################################################update file (twice)
if stp_path:
	print("ARGV INPUT: ", source_list)
else:
	stp_path = str(init_data[0]['default_stp']) 
	print("def ", stp_path)	

study = Setup.DesignStudy.Create()

############################################################OPEN CFD FILE 
study.open(cfd_file) 
																				
scenario = study.getActiveScenario()
design = study.design( "Design 1" )
DSE.UI.ShowMessage(time.ctime()+"\n\n"+"UPDATING MODELS " + stp_path)
design.update( stp_path )
design.update( stp_path )

#############################################################SET MATERIALS														

scenario.selectionMode = "Volume"
scenario.selectionBasis = "Direct"
scenario.selectAll()
scenario.applyMaterial( "Glass" )

vols = Setup.EntityIdList()

scenario.select("Part1.AIR")
scenario.applyMaterial( "Air" )
scenario.applyMaterial( "Air", vols, Setup.Entity.Volume)

#################################### Fan Material Prop

# scenario.select("Part1.HVAC_U_Part1.AIR")
# scenario.applyMaterial( "ComairRotron FlightII 120 2000RPM" )

if 1:
	mat = Setup.Material.Create(scenario, "Internal Fan/Pump", "TEST FAN")

	p = mat.property( "Flow" )
	v = p.variation( "Constant" )
	v.setValue(1000.00, "m3/min")
	p.apply(v)

	p1 = mat.setDirection(0,1,0)
	p = mat.property( "Rotational speed" ) 
	v = p.variation( "Constant" )
	v.setValue( 1000, "RPM")
	p.apply(v)

	vols = Setup.EntityIdList()
	scenario.select("Part1.HVAC_U_Part1.AIR")
	scenario.applyMaterial( mat, vols, Setup.Entity.Volume )

#################################### Air Material Prop
scenario.select("CFDCreatedVolume")
scenario.applyMaterial( "Air" )

DSE.UI.ShowMessage("............................................materials set")

############################################################RUN ANALYSIS
DSE.UI.ShowMessage("............................................run analysis!")

def run_cfd():
	scenario.solverComputer = "MyComputer"
	scenario.flow = "On"
	scenario.heatTransfer = "Off"
	scenario.forcedQuickConvection = "Off"
	scenario.naturalQuickConvection = "Off"
	scenario.continueFrom = "0"
	scenario.analysisMode = "Steady State"
	scenario.iterations = 150
	scenario.run()

run_cfd()

results = scenario.results()

if results is None:
	DSE.UI.ShowMessage( "There are no results !" )
else:
	DSE.UI.ShowMessage( "Results Found !" )
	results.activate()

#################################################Results Post Processing

cp1 = Results.CutPlane.Create(results, "Plane 3")
if not cp1:
	DSE.UI.ShowMessage("Cutplane creation failed")


#############################################Custom analysis plane locations or monitor points
# cp1.setLocation(0.25,0.25,0.5)
# cp1.setNormal(0,0,1)
# mp = Results.MonitorPoint.Create(results, 'mp', 0.1, 0.25, 0.6)
# print("mp value:  ", mp.value("VELOCITY"))

sp1 = DC.SummaryPlane.Create(study.decisionCenter(), cp1)
if not sp1:
	DSE.UI.ShowMessage("Summary plane creation failed")

DSE.UI.ShowMessage("Summary plane is created")
  
summary_data = []
summary_data.append(stp_name)
summary_data.append(time.ctime())

sp_results = DC.SummaryItemResults()
sp1.getResults( sp_results )

for resultType, design in sp_results.iteritems():
	for designName, scenario in design.iteritems():
		for scenarioName, val in scenario.iteritems():
			resultStr = DC.SummaryPlane.ResultTypeToString(resultType)
			name = designName + "::" + scenarioName
			#val = resultStr + "=" + str(val)
			val = str(val)
			DSE.UI.ShowMessage(val)
	summary_data.append(val)

summary_data = str(summary_data)[1:-1]

print("\n\n\n",summary_data,"\n\n\n")
print(os.path.join(base_dir, 'img', stp_name + str(time.time())[-5:] ))

results.activate()

###############################################  write external dataset


output_txt = init_data[0]['output_txt']

with open(output_txt, "a") as f:
    f.write("\n"+str(summary_data))

study.save()

print("\n\nscript done\n\n")
